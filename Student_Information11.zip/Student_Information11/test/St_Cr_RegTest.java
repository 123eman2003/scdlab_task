/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author haroon naeem
 */
public class St_Cr_RegTest {
    
    public St_Cr_RegTest() {
    }
    
//    @BeforeClass
//    public static void setUpClass() {
//    }
//    
//    @AfterClass
//    public static void tearDownClass() {
//    }
//    
//    @Before
//    public void setUp() {
//    }
//    
//    @After
//    public void tearDown() {
//    }
//
//    /**
//     * Test of cr_reg method, of class St_Cr_Reg.
//     */
//    @Test
//    public void testCr_reg() {
//        System.out.println("cr_reg");
//        St_Cr_Reg instance = new St_Cr_Reg();
//        boolean expResult = false;
//        boolean result = instance.cr_reg();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of main method, of class St_Cr_Reg.
//     */;
//    @Test
//    public void testMain() {
//        System.out.println("main");
//        String[] args = null;
//        St_Cr_Reg.main(args);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
     @Test
     public void course_register(){
         St_Cr_Reg scr= new St_Cr_Reg();
         assertTrue(scr.cr_reg());
     }
}
