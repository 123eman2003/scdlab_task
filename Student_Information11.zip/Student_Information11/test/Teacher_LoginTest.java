/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author haroon naeem
 */
public class Teacher_LoginTest {
    
    public Teacher_LoginTest() {
    }
    



    @Test
    public void teascherLogin(){
         Teacher_Login t = new Teacher_Login();
         assertTrue(t.login("Nida", "nida222"));
      
    }
    
}
