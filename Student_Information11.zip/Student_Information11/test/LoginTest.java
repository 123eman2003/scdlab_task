/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author haroon naeem
 */
public class LoginTest {
    
    public LoginTest() {
    }
    
//    @BeforeClass
//    public static void setUpClass() {
//    }
//    
//    @AfterClass
//    public static void tearDownClass() {
//    }
//    
//    @Before
//    public void setUp() {
//    }
//    
//    @After
//    public void tearDown() {
//    }
//
//    /**
//     * Test of st_login method, of class Login.
//     */
//    @Test
//    public void testSt_login() {
//        System.out.println("st_login");
//        Login instance = new Login();
//        boolean expResult = false;
//        boolean result = instance.st_login();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
//
//    /**
//     * Test of main method, of class Login.
//     */
//    @Test
//    public void testMain() {
//        System.out.println("main");
//        String[] args = null;
//        Login.main(args);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
       Login l = new Login();
    @Test
    public void s_loginTest(){
     assertTrue(l.st_login());
    }
    @Test
    public void a_login(){
         assertTrue(l.adm_login());
    }
    @Test
    public void t_login(){
       assertTrue(l.teacher_login());
    }
    
}
