/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 
 */
public class Factory {
    public Dashboard getShape(String user){
        
        if(user==null){
            return null;
        }
        else if(user=="admin"){
            return new FactoryClass1();
        }
        else if(user=="student"){
            return new FactoryClass2();
        }
         else if(user=="teacher"){
            return new FactoryClass3();
        }
        
        return null;
    }
}
