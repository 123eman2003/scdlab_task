/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author
 */
public class FactoryClass2 implements Dashboard{

    Student_Login student_login=new Student_Login();
    @Override
    public void loginChoose() {
   
        student_login.setVisible(true);   
    }
    
}
