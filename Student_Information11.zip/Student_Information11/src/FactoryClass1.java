/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author
 */
public class FactoryClass1 implements Dashboard{

    Admin_Login admin_login=new Admin_Login();
    @Override
    public void loginChoose() {    
                admin_login.setVisible(true);          
           }
    
}
