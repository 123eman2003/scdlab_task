
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author 
 */
public class Server {

    public static void main(String[] args) throws IOException {

        Socket socket;
        InputStreamReader inputStreamReader;
        OutputStreamWriter outputStreamWriter;
        BufferedReader bufferedReader;
        BufferedWriter bufferedWriter;
        ServerSocket serversocket;

        serversocket = new ServerSocket(4000);
        while (true) {
            try {
                socket = serversocket.accept();
                inputStreamReader = new InputStreamReader(socket.getInputStream());
                outputStreamWriter = new OutputStreamWriter(socket.getOutputStream());
                bufferedReader = new BufferedReader(inputStreamReader);
                bufferedWriter = new BufferedWriter(outputStreamWriter);
                while (true) {
                    String msgFromClient = bufferedReader.readLine();
                    if (msgFromClient.equalsIgnoreCase("what is the project?")) {
//                    
                        bufferedWriter.write("Student Information System");
                        bufferedWriter.newLine();
                        bufferedWriter.flush();

                    } else if (msgFromClient.equalsIgnoreCase("how many modules it have?")) {
//                     
                        bufferedWriter.write("it has 3 modules i.e. student, teacher and admin");
////                
                        bufferedWriter.newLine();
                        bufferedWriter.flush();
                    } else if (msgFromClient.equalsIgnoreCase("which ide is used?")) {                    
                        bufferedWriter.write("NetBeans");
                        bufferedWriter.newLine();
                        bufferedWriter.flush();
                    } else if (msgFromClient.equalsIgnoreCase("which database is used?")) {                         
                        bufferedWriter.write("MYSQL Database");

                        bufferedWriter.newLine();
                        bufferedWriter.flush();
                    } else if (msgFromClient.equalsIgnoreCase("BYE")) {                      
                        bufferedWriter.write("have a nice day!");
                        bufferedWriter.newLine();
                        bufferedWriter.flush();
                        break;

                    }

//                  break;
                }
                socket.close();
                inputStreamReader.close();
                outputStreamWriter.close();
                bufferedReader.close();
                bufferedWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
